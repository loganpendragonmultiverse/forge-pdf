# Forge PDF MinGW OCR engine candidate — private review

This is a bounded replacement experiment for the OCR executable in Forge PDF draft PR #16. The existing private preview ZIP and draft PR were not changed. This candidate is **not approved for public release**.

## Build provenance

- Tesseract 5.5.3 source tag, commit `db0ec62f81b0737fbbe184d8fea40af5738f8eef`.
- Official MSYS2 archive `msys2-base-x86_64-20260927.tar.zst`, SHA-256 `8a2095647afbf799d113d0cae35f7544589d059819042635504e75bd2179bd02`, matched the official release digest. Extracted in an isolated temporary directory; no system default or security setting changed.
- Signed MSYS2 packages: GCC 16.2.0-6, MinGW CRT/headers/libwinpthread `14.0.0.r569.g34eeafb7d-1`, CMake 4.4.4-4, Ninja 1.13.2-1.
- vcpkg pinned baseline `3af1d1e60af2b2abf55760538cd607829029b07a`, `x64-mingw-static`. Installed graph: Leptonica 1.85.0, TIFF 4.7.1, liblzma 5.8.1, libwebp 1.6.0, OpenJPEG 2.5.4, libjpeg-turbo 3.1.2, libpng 1.6.50, giflib 5.2.2, zlib 1.3.1, plus vcpkg CMake helpers. The full installed status, ABI files, CMake configuration, build log, and linker map remain under `C:\Users\NINJAK~1\AppData\Local\Temp\fpmingw` for audit.
- Configured Release with GCC, no curl, libarchive, OpenMP, LTO or native CPU tuning; linked with `-static -static-libgcc -static-libstdc++`. Linker map SHA-256 `b4c3dfc531c1bfa6010cef5051ff2517d6de3284721bace7570e5578ece959d3`.

## Result and runtime

- New `tesseract.exe`: 13,176,231 bytes, SHA-256 `8d6d753e54c31b9cdd938328a5f0f6e5ad076bb78a74bc6a22da4e6bf667913f`. Existing MSVC candidate: 5,341,696 bytes, SHA-256 `2df0d8207b34b59dd95f93c0e5cda5eae8d626519d4dc7206a899cc23a82c5b8`.
- PE import table includes `KERNEL32.dll` and Windows UCRT `api-ms-win-crt-*` APIs. It includes no MSVC runtime DLL, MinGW DLL, `msvcrt.dll`, or OCR DLL. The linker map includes static `libgcc.a`, `libgcc_eh.a`, `libstdc++.a`, MinGW CRT, and `libpthread.a`, along with the pinned OCR/image libraries. Dynamic UCRT means compatibility still needs testing on supported Windows versions beyond this Windows 11 x64 device.
- Copied only the OCR executable into an isolated copy of the already tested Forge PDF preview. The original preview ZIP remains intact. Added local GCC Runtime Library Exception/GPL, MinGW CRT/ZPL and winpthreads/MIT/BSD license texts to the candidate's OCR notice tree; existing Tesseract, model and image-library notices were retained. This is a private acceptance copy; its old top-level provenance and hash pinning still refer to the MSVC build, so it must be rebuilt with updated receipt and hashes before any distribution.

## Synthetic checks

- Standalone engine: generated a synthetic PNG containing `FORGE OCR SAMPLE`; Tesseract emitted a searchable PDF whose single page extracted that exact text.
- Packaged GUI copy: opened an image-only synthetic PDF, used **Page actions → OCR searchable image copy**, and saved `app-ocr-output.pdf`. Independent pypdf readback: source has one page and no extracted text; output has one page and extracts `FORGE OCR SAMPLE`. Source SHA-256 `1f66e5e7b31055c4a6f6054d340f00236eec57109c6554b1413d18d861a27bad`; output SHA-256 `891b64f3320f29684fc3e39a4d4aba7a8282c328c23cbc1b90fd9d6f64810d9b`. UI reported save success. Only synthetic data was used.
- This test validates the packaged **image-copy** OCR path with the new engine. It does not validate a source-preserving text-layer path in this candidate, and does not establish any redaction or accessibility guarantee.

## Release gates

1. Incorporate the MinGW engine, exact hashes and source/toolchain provenance into the canonical builder and notices. Replace obsolete MSVC attribution for this variant; retain all linked dependency notices.
2. Audit the exact GCC Runtime Library Exception, MinGW CRT ZPL and winpthreads license coverage against the linker map. The official GCC runtime exception and MSYS2 package declarations support this direction, but the final product notice set and build receipt need independent review.
3. Build a fresh pinned ZIP through the canonical builder, run its negative packaging checks, test packaged OCR again, and verify current PR head and CI. No draft PR push, merge or release was done here.

The alternative removes the unresolved Build Tools MSVC static-runtime redistribution question at the cost of a roughly 7.8 MB larger OCR executable and a new GCC/MinGW notice inventory. It is promising, but not yet a release-ready replacement.
